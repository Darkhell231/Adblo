# AdBlocker (Flutter + Kotlin VpnService)

## Установка
1. `flutter create --org com.example --project-name adblocker adblocker_app`
2. Скопируйте в проект:
   - `pubspec.yaml`            -> корень
   - `lib/main.dart`           -> `lib/main.dart`
   - `android_files/kotlin/*`  -> `android/app/src/main/kotlin/com/example/adblocker/`
   - `android_files/AndroidManifest.xml` -> `android/app/src/main/AndroidManifest.xml`
     (удалите сгенерированный MainActivity.kt, если он дублируется)
3. В `android/app/build.gradle` минимальный SDK: `minSdk = 24`.
4. `flutter run --release`

## Как работает
Приложение поднимает локальный VPN, через который идёт только DNS (маршрут /32).
Запросы к доменам из чёрного списка получают ответ 0.0.0.0, остальные уходят на 1.1.1.1.
Скорость остального трафика не страдает.

## Важно
- Отключите "Частный DNS" (Настройки -> Сеть -> Частный DNS), иначе Android обходит VPN-DNS.
- На Android 13+ разрешите уведомления.
- На Xiaomi/Huawei/Samsung отключите оптимизацию батареи для приложения.
