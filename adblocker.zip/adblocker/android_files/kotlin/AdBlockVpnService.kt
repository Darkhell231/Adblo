package com.example.adblocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Локальный VPN, в туннель которого уходит ТОЛЬКО DNS-трафик (маршрут /32).
 * Остальной трафик идёт напрямую, поэтому скорость не страдает.
 * DNS-запросы к рекламным доменам получают ответ 0.0.0.0, остальные
 * пересылаются на настоящий DNS-сервер.
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        @Volatile var running = false
        val blockedCount = AtomicInteger(0)

        private const val VPN_ADDR = "10.111.222.1"
        private const val VPN_DNS = "10.111.222.2"
        private const val UPSTREAM_DNS = "1.1.1.1"
        private const val CHANNEL_ID = "adblock"
    }

    private var tun: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    private val pool = Executors.newFixedThreadPool(8)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (!running) startVpn()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "AdBlocker", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this))
            .setContentTitle("Блокировка рекламы активна")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(1, n)
        }
    }

    private fun startVpn() {
        Blocklist.load(applicationContext)
        tun = Builder()
            .setSession("AdBlocker")
            .addAddress(VPN_ADDR, 32)
            .addDnsServer(VPN_DNS)
            .addRoute(VPN_DNS, 32)      // только DNS идёт через туннель
            .setBlocking(true)
            .establish() ?: return
        running = true
        reader = Thread { loop() }.also { it.start() }
    }

    private fun stopVpn() {
        running = false
        reader?.interrupt()
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); pool.shutdownNow(); super.onDestroy() }

    // ---------------------------------------------------------------- пакеты

    private fun loop() {
        val input = FileInputStream(tun!!.fileDescriptor)
        val output = FileOutputStream(tun!!.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val len = try { input.read(buf) } catch (_: Exception) { break }
            if (len <= 0) continue
            handle(buf.copyOf(len), output)
        }
    }

    private fun handle(p: ByteArray, out: FileOutputStream) {
        if (p.size < 28 || (p[0].toInt() shr 4) != 4) return
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p[9].toInt() != 17) return                       // только UDP
        val dstPort = u16(p, ihl + 2)
        if (dstPort != 53) return
        val dns = p.copyOfRange(ihl + 8, p.size)
        val q = parseQuestion(dns) ?: return

        if (Blocklist.isBlocked(q.name)) {
            blockedCount.incrementAndGet()
            writePacket(out, p, ihl, blockedResponse(dns, q))
        } else {
            pool.execute {
                try {
                    DatagramSocket().use { s ->
                        protect(s)                           // в обход VPN, иначе петля
                        s.soTimeout = 5000
                        val up = InetAddress.getByName(UPSTREAM_DNS)
                        s.send(DatagramPacket(dns, dns.size, up, 53))
                        val rb = ByteArray(4096)
                        val rp = DatagramPacket(rb, rb.size)
                        s.receive(rp)
                        writePacket(out, p, ihl, rb.copyOf(rp.length))
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private class Question(val name: String, val type: Int, val end: Int)

    private fun parseQuestion(d: ByteArray): Question? {
        if (d.size < 17) return null
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val l = d[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if (l and 0xC0 != 0 || i + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, l, Charsets.US_ASCII))
            i += 1 + l
        }
        if (i + 4 > d.size) return null
        return Question(sb.toString(), u16(d, i), i + 4)
    }

    /** Ответ: A -> 0.0.0.0, AAAA -> :: , остальное -> пустой NOERROR */
    private fun blockedResponse(q: ByteArray, qs: Question): ByteArray {
        val answer = when (qs.type) {
            1 -> byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 0, 0, 0, 0)
            28 -> byteArrayOf(0xC0.toByte(), 0x0C, 0, 28, 0, 1, 0, 0, 0, 60, 0, 16) + ByteArray(16)
            else -> ByteArray(0)
        }
        val r = ByteArray(qs.end + answer.size)
        System.arraycopy(q, 0, r, 0, qs.end)
        r[2] = 0x81.toByte(); r[3] = 0x80.toByte()           // QR, RD, RA, NOERROR
        r[4] = 0; r[5] = 1                                   // QDCOUNT = 1
        r[6] = 0; r[7] = if (answer.isEmpty()) 0 else 1      // ANCOUNT
        r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0             // NS, AR = 0
        System.arraycopy(answer, 0, r, qs.end, answer.size)
        return r
    }

    @Synchronized
    private fun writePacket(out: FileOutputStream, orig: ByteArray, ihl: Int, payload: ByteArray) {
        val total = 20 + 8 + payload.size
        val r = ByteArray(total)
        r[0] = 0x45; r[2] = (total shr 8).toByte(); r[3] = total.toByte()
        r[6] = 0x40; r[8] = 64; r[9] = 17
        System.arraycopy(orig, 16, r, 12, 4)                 // src = бывший dst
        System.arraycopy(orig, 12, r, 16, 4)                 // dst = бывший src
        val c = checksum(r, 20)
        r[10] = (c shr 8).toByte(); r[11] = c.toByte()
        System.arraycopy(orig, ihl + 2, r, 20, 2)            // src port = 53
        System.arraycopy(orig, ihl, r, 22, 2)                // dst port = клиентский
        val ul = 8 + payload.size
        r[24] = (ul shr 8).toByte(); r[25] = ul.toByte()     // checksum UDP = 0 (допустимо для IPv4)
        System.arraycopy(payload, 0, r, 28, payload.size)
        try { out.write(r) } catch (_: Exception) {}
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun checksum(b: ByteArray, len: Int): Int {
        var s = 0L
        var i = 0
        while (i < len) { s += u16(b, i); i += 2 }
        while (s shr 16 != 0L) s = (s and 0xFFFF) + (s shr 16)
        return (s.inv() and 0xFFFF).toInt()
    }
}
