package com.example.adblocker

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Blocklist {
    // Можно добавлять свои списки в формате hosts или "один домен на строку"
    private val sources = listOf(
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt",
        "https://small.oisd.nl/domainswild2"
    )

    @Volatile private var domains: HashSet<String> = hashSetOf()

    fun size() = domains.size

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "blocklist.txt")

    fun load(ctx: Context) {
        val f = cacheFile(ctx)
        val set = HashSet<String>()
        if (f.exists()) {
            f.forEachLine { if (it.isNotBlank()) set.add(it.trim()) }
        } else {
            // встроенный минимум на случай первого запуска без обновления
            set.addAll(listOf(
                "doubleclick.net", "googlesyndication.com", "googleadservices.com",
                "adservice.google.com", "pagead2.googlesyndication.com",
                "adsystem.com", "amazon-adsystem.com", "adnxs.com", "criteo.com",
                "taboola.com", "outbrain.com", "scorecardresearch.com",
                "ads.yahoo.com", "moatads.com", "unityads.unity3d.com",
                "applovin.com", "mopub.com", "adcolony.com", "vungle.com",
                "ads.mail.ru", "an.yandex.ru", "mc.yandex.ru", "yandexadexchange.net"
            ))
        }
        domains = set
    }

    fun update(ctx: Context): Int {
        val set = HashSet<String>()
        var ok = 0
        for (src in sources) {
            try {
                val c = URL(src).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { parseLine(it)?.let(set::add) }
                }
                ok++
            } catch (_: Exception) {}
        }
        if (ok == 0) throw Exception("нет доступа к спискам")
        cacheFile(ctx).writeText(set.joinToString("\n"))
        domains = set
        return set.size
    }

    private fun parseLine(raw: String): String? {
        var l = raw.trim()
        if (l.isEmpty() || l.startsWith("#") || l.startsWith("!")) return null
        // hosts: "0.0.0.0 domain"
        if (l.startsWith("0.0.0.0 ") || l.startsWith("127.0.0.1 ")) {
            l = l.substringAfter(' ').trim().substringBefore('#').trim()
        }
        // adblock: ||domain^
        if (l.startsWith("||")) {
            l = l.removePrefix("||").substringBefore('^')
            if (l.contains('/') || l.contains('*')) return null
        }
        l = l.removePrefix("*.")
        if (l == "localhost" || l.contains(' ') || !l.contains('.')) return null
        return l.lowercase()
    }

    /** Блокируем сам домен и все его поддомены */
    fun isBlocked(host: String): Boolean {
        var h = host.lowercase().trimEnd('.')
        val d = domains
        while (true) {
            if (d.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}
