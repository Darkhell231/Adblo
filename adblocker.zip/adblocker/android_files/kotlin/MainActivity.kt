package com.example.adblocker

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlin.concurrent.thread

class MainActivity : FlutterActivity() {
    private val channelName = "adblocker/vpn"
    private val vpnRequest = 100
    private var pendingResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> {
                        val intent = VpnService.prepare(this)
                        if (intent != null) {
                            pendingResult = result
                            startActivityForResult(intent, vpnRequest)
                        } else {
                            startVpn()
                            result.success(true)
                        }
                    }
                    "stop" -> {
                        startService(Intent(this, AdBlockVpnService::class.java)
                            .setAction(AdBlockVpnService.ACTION_STOP))
                        result.success(true)
                    }
                    "status" -> result.success(
                        mapOf(
                            "running" to AdBlockVpnService.running,
                            "blocked" to AdBlockVpnService.blockedCount.get(),
                            "domains" to Blocklist.size()
                        )
                    )
                    "updateLists" -> thread {
                        try {
                            val n = Blocklist.update(applicationContext)
                            runOnUiThread { result.success(n) }
                        } catch (e: Exception) {
                            runOnUiThread { result.error("UPDATE", e.message, null) }
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun startVpn() {
        val i = Intent(this, AdBlockVpnService::class.java)
            .setAction(AdBlockVpnService.ACTION_START)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i)
        else startService(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequest) {
            if (resultCode == Activity.RESULT_OK) {
                startVpn()
                pendingResult?.success(true)
            } else {
                pendingResult?.error("DENIED", "Разрешение VPN не выдано", null)
            }
            pendingResult = null
        }
    }
}
