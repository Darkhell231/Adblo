import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const AdBlockApp());

class AdBlockApp extends StatelessWidget {
  const AdBlockApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AdBlocker',
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      darkTheme: ThemeData(
          colorSchemeSeed: Colors.teal,
          brightness: Brightness.dark,
          useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _ch = MethodChannel('adblocker/vpn');

  bool _running = false;
  bool _busy = false;
  int _blocked = 0;
  int _domains = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refresh() async {
    try {
      final s = await _ch.invokeMapMethod<String, dynamic>('status');
      if (!mounted || s == null) return;
      setState(() {
        _running = s['running'] as bool;
        _blocked = s['blocked'] as int;
        _domains = s['domains'] as int;
      });
    } on PlatformException catch (_) {}
  }

  Future<void> _toggle(bool on) async {
    setState(() => _busy = true);
    try {
      if (on) {
        // Android покажет системный диалог разрешения VPN
        await _ch.invokeMethod('start');
      } else {
        await _ch.invokeMethod('stop');
      }
    } on PlatformException catch (e) {
      _snack(e.message ?? 'Ошибка');
    }
    await Future.delayed(const Duration(milliseconds: 600));
    await _refresh();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _update() async {
    setState(() => _busy = true);
    try {
      final n = await _ch.invokeMethod<int>('updateLists');
      _snack('Списки обновлены: $n доменов');
    } on PlatformException catch (e) {
      _snack('Не удалось обновить: ${e.message}');
    }
    await _refresh();
    if (mounted) setState(() => _busy = false);
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('AdBlocker')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 16),
            Icon(_running ? Icons.shield : Icons.shield_outlined,
                size: 120, color: _running ? cs.primary : cs.outline),
            const SizedBox(height: 16),
            Text(_running ? 'Защита включена' : 'Защита выключена',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 24),
            Switch(
              value: _running,
              onChanged: _busy ? null : _toggle,
            ),
            const SizedBox(height: 32),
            Card(
              child: ListTile(
                leading: const Icon(Icons.block),
                title: const Text('Заблокировано запросов'),
                trailing: Text('$_blocked',
                    style: Theme.of(context).textTheme.titleLarge),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.list_alt),
                title: const Text('Доменов в чёрном списке'),
                trailing: Text('$_domains',
                    style: Theme.of(context).textTheme.titleLarge),
              ),
            ),
            const Spacer(),
            FilledButton.tonalIcon(
              onPressed: _busy ? null : _update,
              icon: const Icon(Icons.refresh),
              label: const Text('Обновить фильтры'),
            ),
          ],
        ),
      ),
    );
  }
}
